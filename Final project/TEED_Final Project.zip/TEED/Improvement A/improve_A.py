
# ------------------------------------------------------------
# TEED inference + "green-colored regions + high-texture" boost
# Works with: TEED-main/TEED-main codebase + 7_model.pth
# Input: a folder of jpg/png images (e.g., TEED-main/TEED-main/data)
# Output: multiple debug maps + final edge binary result
# ------------------------------------------------------------

import os
import sys
import glob
import cv2
import numpy as np
import torch

# ============== 1) PATHS: EDIT THESE 3 ======================
TEED_CODE_DIR = r"C:\Users\user\Downloads\TEED-main\TEED-main"   # where ted.py, utils/, etc.
CKPT          = r"C:\Users\user\Downloads\TEED-main\7_model.pth" # your weights
IMG_DIR       = r"C:\Users\user\Downloads\TEED-main\TEED-main\data"  # your jpg folder
OUT_DIR       = r"C:\Users\user\Downloads\TEED-main\preds_green_tex"  # output folder
# ============================================================

sys.path.append(TEED_CODE_DIR)
from ted import TED

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def minmax01(x: np.ndarray, eps=1e-6):
    x = x.astype(np.float32)
    mn, mx = float(x.min()), float(x.max())
    return (x - mn) / (mx - mn + eps)

def read_bgr(path):
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {path}")
    return img

def bgr_to_tensor(img_bgr, device, resize_to=None):
    """
    TEED expects float tensor BCHW, usually normalized.
    We'll do:
      - optional resize
      - BGR->RGB
      - [0,1]
      - (x - mean) / std  (ImageNet-like)
    """
    if resize_to is not None:
        img_bgr = cv2.resize(img_bgr, resize_to, interpolation=cv2.INTER_AREA)

    img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    x = img_rgb.astype(np.float32) / 255.0

    mean = np.array([0.485, 0.456, 0.406], np.float32)
    std  = np.array([0.229, 0.224, 0.225], np.float32)
    x = (x - mean) / std

    x = np.transpose(x, (2, 0, 1))  # CHW
    x = torch.from_numpy(x).unsqueeze(0).to(device)  # BCHW
    return x

def green_mask_hsv(img_bgr,
                   H_LOW=25, H_HIGH=95,
                   S_LOW=40, S_HIGH=255,
                   V_LOW=40, V_HIGH=255):
    """
    cv2 HSV: H in [0,179], S,V in [0,255]
    These ranges catch vegetation-ish green.
    Adjust H range if needed.
    """
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    lower = np.array([H_LOW, S_LOW, V_LOW], dtype=np.uint8)
    upper = np.array([H_HIGH, S_HIGH, V_HIGH], dtype=np.uint8)
    m = cv2.inRange(hsv, lower, upper)  # 0/255
    return (m > 0).astype(np.float32)

def texture_map_from_v(img_bgr, blur_ksize=3):
    """
    High-texture: gradient magnitude on V channel.
    tex in [0,1] after minmax normalization.
    """
    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    v = hsv[:, :, 2].astype(np.float32)

    if blur_ksize and blur_ksize > 1:
        v = cv2.GaussianBlur(v, (blur_ksize, blur_ksize), 0)

    gx = cv2.Sobel(v, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(v, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.sqrt(gx * gx + gy * gy)

    tex = minmax01(mag)
    return tex

def smooth_mask(m, k=7):
    m8 = (m * 255).astype(np.uint8)
    m8 = cv2.medianBlur(m8, k)
    return (m8.astype(np.float32) / 255.0)

def percentile_threshold(x01, p=95):
    return np.percentile(x01.reshape(-1), p)

@torch.no_grad()
def run_one(model, device, img_path,
            resize_to=None,
            GAMMA=0.8,
            TEX_POWER=1.0,
            GATE="green_tex",   # "green" | "tex" | "green_tex"
            TH_MODE="percentile", # "percentile" | "fixed"
            TH_P=95,
            TH_FIXED=0.5,
            SMOOTH_K=7):
    """
    Produces:
      out1_prob, final_prob, tex, mask_green, mask_green_tex, edge_prob_boost, edge_bin
    """

    img_bgr = read_bgr(img_path)
    H0, W0 = img_bgr.shape[:2]

    # --- masks on ORIGINAL resolution (before resize) ---
    m_green = green_mask_hsv(img_bgr)
    tex = texture_map_from_v(img_bgr)

    # high-texture mask (soft)
    # choose a tex threshold by percentile (more stable)
    tex_thr = np.percentile(tex.reshape(-1), 80)  # 80~90 often good
    m_tex = (tex > tex_thr).astype(np.float32)

    if GATE == "green":
        gate = m_green
    elif GATE == "tex":
        gate = m_tex
    else:
        gate = (m_green * m_tex)

    # smooth gate to avoid blocky artifacts
    gate = smooth_mask(gate, k=SMOOTH_K)

    # --- model inference ---
    x = bgr_to_tensor(img_bgr, device=device, resize_to=resize_to)
    outs = model(x)  # list: [out1, out2, out3, final_cat]
    out1 = torch.sigmoid(outs[0])[0, 0].cpu().numpy()
    final = torch.sigmoid(outs[-1])[0, 0].cpu().numpy()

    # resize outputs back to original size if resized
    if resize_to is not None and (resize_to[0] != W0 or resize_to[1] != H0):
        out1 = cv2.resize(out1, (W0, H0), interpolation=cv2.INTER_CUBIC)
        final = cv2.resize(final, (W0, H0), interpolation=cv2.INTER_CUBIC)

    # --- boost logic ---
    # idea: in vegetation hard regions, add more fine texture detail from out1 & tex
    # edge_prob = final + GAMMA * (out1 - final) * (tex^TEX_POWER) * gate
    tex_w = np.power(tex, TEX_POWER).astype(np.float32)
    # ===== Fix: align shapes (final, out1, tex, gate) =====
    H, W = final.shape  # use final as reference

    if out1.shape != (H, W):
        out1 = cv2.resize(out1, (W, H), interpolation=cv2.INTER_CUBIC)

    if tex.shape != (H, W):
        tex = cv2.resize(tex, (W, H), interpolation=cv2.INTER_LINEAR)

    if gate.shape != (H, W):
        gate = cv2.resize(gate, (W, H), interpolation=cv2.INTER_LINEAR)

    tex_w = np.power(tex, TEX_POWER).astype(np.float32)
    # ================================================

    edge_prob = final + GAMMA * (out1 - final) * tex_w * gate
    edge_prob = np.clip(edge_prob, 0, 1)

    # --- threshold ---
    if TH_MODE == "fixed":
        thr = TH_FIXED
    else:
        thr = percentile_threshold(edge_prob, p=TH_P)

    edge_bin = (edge_prob > thr).astype(np.uint8) * 255

    # also make nice visualizations
    out1_vis  = (minmax01(out1) * 255).astype(np.uint8)   # IMPORTANT: use minmax to see details
    final_vis = (minmax01(final) * 255).astype(np.uint8)
    tex_vis   = (minmax01(tex) * 255).astype(np.uint8)
    gate_vis  = (minmax01(gate) * 255).astype(np.uint8)
    green_vis = (m_green * 255).astype(np.uint8)

    return {
        "img_bgr": img_bgr,
        "out1_prob": out1,
        "final_prob": final,
        "edge_prob": edge_prob,
        "edge_bin": edge_bin,
        "tex_vis": tex_vis,
        "gate_vis": gate_vis,
        "green_vis": green_vis,
        "out1_vis": out1_vis,
        "final_vis": final_vis,
        "thr": float(thr),
    }

def main():
    ensure_dir(OUT_DIR)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = TED().to(device)

    # safer torch.load on newer torch:
    try:
        sd = torch.load(CKPT, map_location=device, weights_only=True)
    except TypeError:
        sd = torch.load(CKPT, map_location=device)

    model.load_state_dict(sd)
    model.eval()

    img_paths = []
    for ext in ("*.jpg", "*.jpeg", "*.png", "*.bmp"):
        img_paths += glob.glob(os.path.join(IMG_DIR, ext))
    img_paths = sorted(img_paths)

    if len(img_paths) == 0:
        print(f"[ERROR] No images found in: {IMG_DIR}")
        return

    # -------- you can tune these ----------
    RESIZE_TO = None          # e.g. (512,512) or None (keep original)
    GAMMA = 0.8               # boost strength (0.3~1.2)
    TEX_POWER = 1.0           # 1.0 normal, 1.5 emphasize strong texture
    GATE = "green_tex"        # "green" | "tex" | "green_tex"
    TH_MODE = "percentile"    # percentile is usually robust
    TH_P = 95                 # 92~97
    TH_FIXED = 0.5
    SMOOTH_K = 7              # 5/7/9
    # -------------------------------------

    print(f"Device: {device}")
    print(f"Images: {len(img_paths)}")
    print(f"Output: {OUT_DIR}")

    for p in img_paths:
        name = os.path.splitext(os.path.basename(p))[0]

        pack = run_one(
            model, device, p,
            resize_to=RESIZE_TO,
            GAMMA=GAMMA,
            TEX_POWER=TEX_POWER,
            GATE=GATE,
            TH_MODE=TH_MODE,
            TH_P=TH_P,
            TH_FIXED=TH_FIXED,
            SMOOTH_K=SMOOTH_K
        )

        # save all debug maps
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_orig.png"), pack["img_bgr"])
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_out1_vis.png"), pack["out1_vis"])
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_final_vis.png"), pack["final_vis"])
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_tex.png"), pack["tex_vis"])
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_mask_green.png"), pack["green_vis"])
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_gate_green_tex.png"), pack["gate_vis"])

        # edge prob visualization (minmax for visibility)
        edge_vis = (minmax01(pack["edge_prob"]) * 255).astype(np.uint8)
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_edge_prob_boost_vis.png"), edge_vis)

        # final binary
        cv2.imwrite(os.path.join(OUT_DIR, f"{name}_edge_bin.png"), pack["edge_bin"])

        print(f"[OK] {name}  thr={pack['thr']:.4f}")

    print("Done.")

if __name__ == "__main__":
    main()
